// This is the command sequence that initializes the SSD1680 driver

{
#ifdef TFT_BUSY
    pinMode(TFT_BUSY, INPUT);
#endif
#ifdef TFT_ENABLE
    pinMode(TFT_ENABLE, OUTPUT);
    digitalWrite(TFT_ENABLE, HIGH);
#endif  
    // Hardware reset
    digitalWrite(TFT_RST, LOW);
    delay(10);
    digitalWrite(TFT_RST, HIGH);
    delay(120);

    // Wait for busy signal
    CHECK_BUSY();
    writecommand(0x12); // Software reset
    CHECK_BUSY();
    // Set border waveform
    writecommand(0x3C);
    writedata(0x05);
    // Set driver output control
    writecommand(0x01);
    writedata((EPD_HEIGHT - 1) % 256); // 
    writedata((EPD_HEIGHT - 1) / 256); // 
    writedata(0x00);

    // Set data transfer way
    writecommand(0x11);              
    writedata(0x03);                   

    // Set RAM X address range
    writecommand(0x44);
    writedata(0x00);
    writedata(EPD_WIDTH / 8 - 1); // 
    // Set RAM Y address range
    writecommand(0x45);
    writedata(0x00);
    writedata(0x00);
    writedata((EPD_HEIGHT - 1) % 256); 
    writedata((EPD_HEIGHT - 1) / 256); 
  

    // Read built-in temperature sensor
    writecommand(0x18);
    writedata(0x80);

    // Set RAM address counter
    writecommand(0x4E);
    writedata(0x00);
    writecommand(0x4F);
    writedata(0x00); 
    writedata(0x00); 
    CHECK_BUSY();

    //set ic offset
    setViewport(0 ,0 ,EPD_WIDTH - COL_OFFSET ,EPD_HEIGHT - ROW_OFFSET);

    
}
